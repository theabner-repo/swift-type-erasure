// Type Erasure
//📸✨ www.instagram.com/abner.abbey


protocol Sumable {
    
    associatedtype SomeType
    
    func sum(_ a: SomeType, _ b: SomeType) -> SomeType
    
}

struct IntStruct: Sumable {
    
    typealias SomeType = Int
    
    func sum(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
    
}

struct DoubleStruct: Sumable {
    
    typealias SomeType = Double
    
    func sum(_ a: Double, _ b: Double) -> Double {
        return a + b
    }
}


struct AnySumable<T>: Sumable {
    
    private let _sum: (_: T, _: T) -> T
    
    init<U: Sumable>(sumable: U) where U.SomeType == T {
        
        self._sum = sumable.sum
    }
    
    func sum(_ a: T, _ b: T) -> T {
        return _sum(a, b)
    }
    
}

struct MyStruct {
    
    let sumable: AnySumable<Int>
    
}

let strct = MyStruct(sumable: AnySumable(sumable: IntStruct()))

print(strct.sumable.sum(4, 5))


